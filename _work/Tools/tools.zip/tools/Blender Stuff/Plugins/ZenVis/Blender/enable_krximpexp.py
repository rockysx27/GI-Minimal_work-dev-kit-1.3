import bpy

bpy.ops.wm.addon_enable(module='KrxImpExp')
bpy.ops.wm.save_userpref()