#----------------------------------------------------
# Progress Bar & Error Box                          #
#----------------------------------------------------

def show_progress_bar(caption, percent):
	#print(caption)
	pass

def hide_progress_bar():
	show_progress_bar(1.0, "Done!")	

def show_error_box(titl, msg):
	print(msg)