More information in Manual.pdf
Mehr Informationen in Handbuch.pdf