Kerrax ASC Exporter for 3D Studio Max 6,7,8
-------------------------------------------

This is a plugin for 3D Studio Max. It can export files of models for Gothic 1-2
in the ASC format. The plugin has the same functional capabilities as ZenGin ASC Exporter.
It was written because ZenGin ASC Exporter does not work on 3D Studio Max 6 or later.

Installation steps (under the assumption that 3d Studio Max 
was installed to the folder C:\3dsmax)
1) Exit from 3D Studio Max, if it is running.
2) Copy the file krxexp.dle to the folder C:\3dsmax\stdplugs
3) Delete the file krxexp.cfg (do not delete another files!) 
from the folder C:\3dsmax\plugcfg, if there is. 
4) Run 3D Studio Max again.

Vitaly Baranov "Kerrax" (kerrax@mail.ru).